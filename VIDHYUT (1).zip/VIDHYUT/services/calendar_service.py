import datetime

from core import config
from core.tooling import safe
from services import google_accounts as ga


@safe
def calendar_list_events(account: str = "", days_ahead: int = 7, max_results: int = 15) -> str:
    """List upcoming Google Calendar events for the next N days."""
    s, alias = ga.build("calendar", "v3", account)
    now = datetime.datetime.now(datetime.timezone.utc)
    ev = s.events().list(calendarId="primary", timeMin=now.isoformat(),
                         timeMax=(now + datetime.timedelta(days=days_ahead)).isoformat(),
                         singleEvents=True, orderBy="startTime", maxResults=max_results).execute()
    rows = []
    for e in ev.get("items", []):
        st = e["start"].get("dateTime", e["start"].get("date"))
        rows.append(f"{st} | {e.get('summary', '(no title)')} | {e.get('location', '')}")
    return f"[{alias}]\n" + ("\n".join(rows) or "No upcoming events.")


@safe
def calendar_create_event(title: str, start_iso: str, end_iso: str, account: str = "",
                          description: str = "", location: str = "") -> str:
    """Create a calendar event. start_iso/end_iso like 2026-12-01T15:00:00 (local time)."""
    s, alias = ga.build("calendar", "v3", account)
    tz = config.get("timezone")
    body = {"summary": title, "description": description, "location": location,
            "start": {"dateTime": start_iso, "timeZone": tz}, "end": {"dateTime": end_iso, "timeZone": tz}}
    e = s.events().insert(calendarId="primary", body=body).execute()
    return f"Event created on [{alias}]: {e.get('htmlLink')}"
