"""Multi-account Google OAuth2: one token file per account in %APPDATA%\\VIDHYUT\\tokens."""
import json
import re

from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import build as _build

from core import config
from core.events import bus

SCOPES = [
    "https://www.googleapis.com/auth/gmail.modify",
    "https://www.googleapis.com/auth/drive",
    "https://www.googleapis.com/auth/calendar",
    "https://www.googleapis.com/auth/youtube.upload",
    "https://www.googleapis.com/auth/youtube.readonly",
]


def _load() -> dict:
    try:
        return json.loads(config.ACCOUNTS_FILE.read_text(encoding="utf-8"))
    except Exception:
        return {"accounts": {}, "active": ""}


def _save(d: dict):
    config.ACCOUNTS_FILE.write_text(json.dumps(d, indent=2), encoding="utf-8")


def slug(alias: str) -> str:
    return re.sub(r"[^a-z0-9_-]+", "-", alias.strip().lower()).strip("-") or "account"


def list_accounts() -> dict:
    return _load()["accounts"]


def active() -> str:
    d = _load()
    return d["active"] if d["active"] in d["accounts"] else ""


def set_active(alias: str):
    d = _load()
    if alias not in d["accounts"]:
        raise RuntimeError(f"No account named '{alias}'.")
    d["active"] = alias
    _save(d)
    bus.accounts_changed.emit()


def remove(alias: str):
    d = _load()
    d["accounts"].pop(alias, None)
    if d["active"] == alias:
        d["active"] = next(iter(d["accounts"]), "")
    _save(d)
    (config.TOKENS_DIR / f"{alias}.json").unlink(missing_ok=True)
    bus.accounts_changed.emit()


def add_account(alias: str) -> str:
    """BLOCKING: opens the browser for consent. Run from a background thread. Returns email."""
    if not config.CREDENTIALS_FILE.exists():
        raise RuntimeError("credentials.json is missing. Import it in SETTINGS first.")
    alias = slug(alias)
    flow = InstalledAppFlow.from_client_secrets_file(str(config.CREDENTIALS_FILE), SCOPES)
    creds = flow.run_local_server(port=0, prompt="select_account consent")
    (config.TOKENS_DIR / f"{alias}.json").write_text(creds.to_json(), encoding="utf-8")
    svc = _build("gmail", "v1", credentials=creds, cache_discovery=False)
    email = svc.users().getProfile(userId="me").execute()["emailAddress"]
    d = _load()
    d["accounts"][alias] = {"email": email}
    if not d["active"]:
        d["active"] = alias
    _save(d)
    bus.accounts_changed.emit()
    return email


def resolve(query: str = "") -> str:
    accts = list_accounts()
    if not accts:
        raise RuntimeError("No Google accounts connected. Open the ACCOUNTS tab and add one.")
    q = (query or "").strip().lower()
    if not q:
        a = active()
        if a:
            return a
        if len(accts) == 1:
            return next(iter(accts))
        raise RuntimeError(f"Several accounts exist; say which one. Available: {', '.join(accts)}")
    if q in accts:
        return q
    q2 = slug(q)
    if q2 in accts:
        return q2
    hits = [a for a, m in accts.items() if q in a or a in q or q in m.get("email", "").lower()]
    if len(hits) == 1:
        return hits[0]
    raise RuntimeError(f"Unknown/ambiguous account '{query}'. Available aliases: {', '.join(accts)}")


def get_credentials(alias: str) -> Credentials:
    f = config.TOKENS_DIR / f"{alias}.json"
    if not f.exists():
        raise RuntimeError(f"Token for '{alias}' missing. Re-authenticate it in the ACCOUNTS tab.")
    creds = Credentials.from_authorized_user_file(str(f), SCOPES)
    if not creds.valid:
        if creds.refresh_token:
            try:
                creds.refresh(Request())
                f.write_text(creds.to_json(), encoding="utf-8")
            except Exception:
                raise RuntimeError(f"Login for '{alias}' expired. Re-authenticate it in the ACCOUNTS tab.")
        else:
            raise RuntimeError(f"Login for '{alias}' expired. Re-authenticate it in the ACCOUNTS tab.")
    return creds


def build(api: str, version: str, account: str = ""):
    alias = resolve(account)
    return _build(api, version, credentials=get_credentials(alias), cache_discovery=False), alias
