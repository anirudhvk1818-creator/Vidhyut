import os
import re
import subprocess
import time
from pathlib import Path

import requests

from core import config
from core.approvals import DENIED, request_approval
from core.tooling import safe

RISKY = (".exe", ".msi", ".bat", ".cmd", ".ps1", ".vbs", ".scr", ".com")


@safe
def search_files(name_query: str, folder: str = "", max_results: int = 20) -> str:
    """Search for files/folders on the PC by part of the name. folder empty = Desktop, Documents, Downloads, Videos, Pictures, Music."""
    home = Path.home()
    roots = [Path(folder)] if folder else [home / d for d in ("Desktop", "Documents", "Downloads", "Videos", "Pictures", "Music")]
    q, found, deadline = name_query.lower(), [], time.time() + 20
    for root in roots:
        for dp, dn, fn in os.walk(root):
            dn[:] = [d for d in dn if not d.startswith(".") and d not in ("node_modules", "__pycache__", "AppData")]
            for n in dn + fn:
                if q in n.lower():
                    found.append(os.path.join(dp, n))
                    if len(found) >= max_results:
                        return "\n".join(found)
            if time.time() > deadline:
                return "\n".join(found) + "\n(search time limit reached)"
    return "\n".join(found) or "Nothing found."


@safe
def open_path(path: str) -> str:
    """Open a file or folder with its default program (not executables - use install tool for those)."""
    if not os.path.exists(path):
        return f"Not found: {path}"
    if path.lower().endswith(RISKY):
        return "Refused: executables must go through run_installer (needs approval)."
    os.startfile(path) if os.name == "nt" else subprocess.Popen(["xdg-open", path])
    return f"Opened {path}"


@safe
def launch_app(name: str) -> str:
    """Launch an installed application by name or command (e.g. notepad, calc, chrome, spotify)."""
    if not re.fullmatch(r"[\w .\\:/()\-]+", name):
        return "Refused: unsafe characters in app name."
    if os.name == "nt":
        subprocess.Popen(f'start "" "{name}"', shell=True)
    else:
        subprocess.Popen([name])
    return f"Launching {name}"


@safe
def delete_file(path: str) -> str:
    """Delete a file or folder (moved to Recycle Bin). User approval required."""
    from send2trash import send2trash
    if not os.path.exists(path):
        return f"Not found: {path}"
    if request_approval("DELETE FILE / FOLDER", {"Path": path}, note="Goes to the Recycle Bin.") is None:
        return DENIED
    send2trash(path)
    return f"Moved to Recycle Bin: {path}"


@safe
def move_file(source: str, destination: str) -> str:
    """Move/rename a file or folder. Will not overwrite existing files."""
    import shutil
    if not os.path.exists(source):
        return f"Not found: {source}"
    dest = Path(destination)
    if dest.is_dir():
        dest = dest / Path(source).name
    if dest.exists():
        return f"Refused: {dest} already exists."
    dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.move(source, str(dest))
    return f"Moved to {dest}"


@safe
def download_file(url: str, filename: str = "") -> str:
    """Download a file from the internet into the Downloads folder."""
    name = filename or url.split("?")[0].rstrip("/").split("/")[-1] or "download.bin"
    dest = config.DOWNLOADS_DIR / name
    if dest.suffix.lower() in RISKY:
        if request_approval("DOWNLOAD PROGRAM FILE", {"URL": url, "Save as": str(dest)}) is None:
            return DENIED
    with requests.get(url, stream=True, timeout=60) as r:
        r.raise_for_status()
        with open(dest, "wb") as f:
            for chunk in r.iter_content(1024 * 256):
                f.write(chunk)
    return f"Downloaded to {dest}"


@safe
def run_installer(path: str) -> str:
    """Run a downloaded installer (.exe/.msi). User approval required; Windows may also show a UAC prompt."""
    if not os.path.isfile(path):
        return f"Not found: {path}"
    if request_approval("INSTALL SOFTWARE", {"Installer": path},
                        note="Only approve installers you downloaded from a source you trust.") is None:
        return DENIED
    os.startfile(path)
    return "Installer started. Follow its window / UAC prompt."


@safe
def winget_search(query: str) -> str:
    """Search for installable software with Windows Package Manager (winget)."""
    r = subprocess.run(["winget", "search", query, "--accept-source-agreements"], capture_output=True, text=True, timeout=60)
    return r.stdout[-3000:] or r.stderr[-500:]


@safe
def winget_install(package_id: str) -> str:
    """Install software silently via winget using its exact package id (e.g. VideoLAN.VLC). User approval required."""
    if not re.fullmatch(r"[\w.\-+]+", package_id):
        return "Refused: invalid package id."
    if request_approval("INSTALL SOFTWARE (winget)", {"Package": package_id}) is None:
        return DENIED
    flags = subprocess.CREATE_NEW_CONSOLE if os.name == "nt" else 0
    subprocess.Popen(["winget", "install", "--id", package_id, "-e", "--accept-package-agreements",
                      "--accept-source-agreements"], creationflags=flags)
    return f"Installing {package_id} in a separate console window."
