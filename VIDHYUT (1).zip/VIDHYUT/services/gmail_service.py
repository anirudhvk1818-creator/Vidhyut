import base64
from email.mime.text import MIMEText

from core.approvals import DENIED, request_approval
from core.tooling import safe
from services import google_accounts as ga


def _body_text(payload) -> str:
    if payload.get("mimeType", "").startswith("text/plain") and payload.get("body", {}).get("data"):
        return base64.urlsafe_b64decode(payload["body"]["data"]).decode("utf-8", "ignore")
    for part in payload.get("parts", []) or []:
        t = _body_text(part)
        if t:
            return t
    return ""


@safe
def gmail_list_emails(account: str = "", query: str = "in:inbox", max_results: int = 5) -> str:
    """List emails from a Gmail account. query uses Gmail search syntax (e.g. 'is:unread', 'from:boss@x.com').
    account = exact alias of the Google account (empty = active account)."""
    s, alias = ga.build("gmail", "v1", account)
    res = s.users().messages().list(userId="me", q=query, maxResults=max_results).execute()
    rows = []
    for m in res.get("messages", []):
        d = s.users().messages().get(userId="me", id=m["id"], format="metadata",
                                     metadataHeaders=["From", "Subject", "Date"]).execute()
        h = {x["name"]: x["value"] for x in d["payload"]["headers"]}
        rows.append(f"id={m['id']} | From: {h.get('From')} | Subject: {h.get('Subject')} | {h.get('Date')} | {d.get('snippet', '')[:160]}")
    return f"[{alias}]\n" + ("\n".join(rows) or "No emails found.")


@safe
def gmail_read_email(message_id: str, account: str = "") -> str:
    """Read the full text of one Gmail message by id (from gmail_list_emails)."""
    s, alias = ga.build("gmail", "v1", account)
    d = s.users().messages().get(userId="me", id=message_id, format="full").execute()
    h = {x["name"]: x["value"] for x in d["payload"]["headers"]}
    body = _body_text(d["payload"]) or d.get("snippet", "")
    return f"From: {h.get('From')}\nSubject: {h.get('Subject')}\nDate: {h.get('Date')}\n\n{body[:6000]}"


@safe
def gmail_send_email(to: str, subject: str, body: str, account: str = "") -> str:
    """Send an email from a Gmail account. The user must approve in a pop-up first."""
    s, alias = ga.build("gmail", "v1", account)
    email = ga.list_accounts()[alias]["email"]
    r = request_approval("SEND EMAIL (Gmail)",
                         {"From": f"{alias} <{email}>", "To": to, "Subject": subject, "Body": body},
                         editable=["To", "Subject", "Body"])
    if r is None:
        return DENIED
    msg = MIMEText(r["Body"], "plain", "utf-8")
    msg["to"], msg["subject"] = r["To"], r["Subject"]
    raw = base64.urlsafe_b64encode(msg.as_bytes()).decode()
    s.users().messages().send(userId="me", body={"raw": raw}).execute()
    return f"Email sent from {email} to {r['To']}."
