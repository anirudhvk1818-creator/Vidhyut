"""Playwright with a PERSISTENT profile (cookies/sessions survive). Uses installed Microsoft Edge,
so no browser download is needed on Windows. Always called from the single engine worker thread."""
from urllib.parse import urlparse

from core import config
from core.approvals import DENIED, request_approval
from core.tooling import safe

SENSITIVE = ("bank", "paypal", "login", "signin", "sign-in", "accounts.google", "password", "checkout",
             "payment", "netbanking", "wallet", "login.live", "account.microsoft", "auth")

_pw = None
_ctx = None


def _page():
    global _pw, _ctx
    from playwright.sync_api import sync_playwright
    if _ctx is None:
        _pw = sync_playwright().start()
        try:
            _ctx = _pw.chromium.launch_persistent_context(str(config.PROFILE_DIR), channel="msedge",
                                                          headless=False, accept_downloads=True,
                                                          viewport=None, args=["--start-maximized"])
        except Exception:
            _ctx = _pw.chromium.launch_persistent_context(str(config.PROFILE_DIR), headless=False,
                                                          accept_downloads=True)
    pages = _ctx.pages
    return pages[-1] if pages else _ctx.new_page()


def shutdown():
    global _pw, _ctx
    try:
        if _ctx:
            _ctx.close()
        if _pw:
            _pw.stop()
    except Exception:
        pass
    _ctx = _pw = None


def _norm(url: str) -> str:
    return url if url.startswith(("http://", "https://")) else "https://" + url


def _is_sensitive(url: str) -> bool:
    return any(k in url.lower() for k in SENSITIVE)


@safe
def browser_open(url: str) -> str:
    """Open a website in VIDHYUT's persistent browser. Sensitive/login sites need user approval."""
    url = _norm(url)
    if _is_sensitive(url):
        if request_approval("OPEN SENSITIVE WEBSITE", {"URL": url}) is None:
            return DENIED
    p = _page()
    p.goto(url, wait_until="domcontentloaded", timeout=45000)
    return f"Opened: {p.title()} ({p.url})"


@safe
def browser_login_assist(url: str) -> str:
    """Open a login page so the USER can sign in manually; the session is saved in the secure profile
    and reused later. VIDHYUT never types passwords."""
    url = _norm(url)
    if request_approval("OPEN LOGIN PAGE", {"URL": url},
                        note="You will log in yourself. The session is saved in VIDHYUT's private browser profile.") is None:
        return DENIED
    _page().goto(url, wait_until="domcontentloaded", timeout=45000)
    return "Login page is open. Ask the user to sign in, then continue when they say they're done."


@safe
def browser_read_page(max_chars: int = 4000) -> str:
    """Return the visible text of the current page."""
    p = _page()
    return f"{p.title()} | {p.url}\n\n" + p.inner_text("body")[:max_chars]


@safe
def browser_click(target: str) -> str:
    """Click an element by its visible text, or by a CSS selector."""
    p = _page()
    try:
        p.get_by_text(target, exact=False).first.click(timeout=5000)
    except Exception:
        p.click(target, timeout=5000)
    p.wait_for_load_state("domcontentloaded")
    return f"Clicked '{target}'. Now at {p.url}"


@safe
def browser_type(selector: str, text: str, press_enter: bool = False) -> str:
    """Type text into an input field (CSS selector). Refuses password fields."""
    p = _page()
    if p.eval_on_selector(selector, "e => (e.type || '').toLowerCase()") == "password":
        return "Refused: VIDHYUT never types passwords. Ask the user to log in manually (browser_login_assist)."
    p.fill(selector, text)
    if press_enter:
        p.press(selector, "Enter")
    return "Typed."


@safe
def browser_download_by_click(target: str) -> str:
    """Click a download button/link (by text or selector) and save the file to the Downloads folder."""
    p = _page()
    with p.expect_download(timeout=90000) as d:
        try:
            p.get_by_text(target, exact=False).first.click(timeout=5000)
        except Exception:
            p.click(target, timeout=5000)
    dl = d.value
    dest = config.DOWNLOADS_DIR / dl.suggested_filename
    if dest.suffix.lower() in (".exe", ".msi", ".bat", ".cmd", ".ps1"):
        if request_approval("SAVE EXECUTABLE FILE", {"File": str(dest), "From": dl.url}) is None:
            dl.cancel()
            return DENIED
    dl.save_as(str(dest))
    return f"Downloaded to {dest}"


@safe
def browser_close() -> str:
    """Close the browser window."""
    shutdown()
    return "Browser closed."
