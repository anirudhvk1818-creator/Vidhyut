import os

from googleapiclient.http import MediaFileUpload

from core.approvals import DENIED, request_approval
from core.events import bus
from core.tooling import safe
from services import google_accounts as ga


@safe
def youtube_upload_video(file_path: str, account: str = "", topic_hint: str = "", privacy: str = "private") -> str:
    """Upload a video file from the PC to a YouTube channel. Gemini writes SEO title/description/tags.
    account = alias of the Google account that owns the channel. privacy: private, unlisted or public.
    The user reviews/edits everything in an approval pop-up before upload."""
    from core.gemini_engine import engine
    if not os.path.isfile(file_path):
        return f"Video file not found: {file_path}"
    yt, alias = ga.build("youtube", "v3", account)
    email = ga.list_accounts()[alias]["email"]
    hint = topic_hint or os.path.splitext(os.path.basename(file_path))[0]
    meta = engine.quick_json(
        f"Write SEO-optimised YouTube metadata for a video about: {hint}. "
        'JSON keys: "title" (max 90 chars, catchy), "description" (3 short paragraphs + 3-5 hashtags), '
        '"tags" (array of 10-15 keywords).')
    r = request_approval(
        "UPLOAD VIDEO TO YOUTUBE",
        {"Account": f"{alias} <{email}>", "File": file_path,
         "Title": meta.get("title", hint)[:100], "Description": meta.get("description", ""),
         "Tags (comma separated)": ", ".join(meta.get("tags", [])),
         "Privacy (private / unlisted / public)": privacy},
        editable=["Title", "Description", "Tags (comma separated)", "Privacy (private / unlisted / public)"])
    if r is None:
        return DENIED
    priv = r["Privacy (private / unlisted / public)"].strip().lower()
    priv = priv if priv in ("private", "unlisted", "public") else "private"
    tags = [t.strip() for t in r["Tags (comma separated)"].split(",") if t.strip()]
    body = {"snippet": {"title": r["Title"][:100], "description": r["Description"], "tags": tags, "categoryId": "22"},
            "status": {"privacyStatus": priv, "selfDeclaredMadeForKids": False}}
    req = yt.videos().insert(part="snippet,status", body=body,
                             media_body=MediaFileUpload(file_path, chunksize=8 * 1024 * 1024, resumable=True))
    resp = None
    while resp is None:
        status, resp = req.next_chunk()
        if status:
            bus.status.emit(f"⬆ YouTube upload {int(status.progress() * 100)}%")
    return f"Uploaded ({priv}): https://youtu.be/{resp['id']}"
