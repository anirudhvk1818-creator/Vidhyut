"""Outlook / Microsoft 365 mail through Microsoft Graph (msal, interactive sign-in once)."""
import msal
import requests

from core import config
from core.approvals import DENIED, request_approval
from core.tooling import safe

SCOPES = ["Mail.ReadWrite", "Mail.Send", "User.Read"]
GRAPH = "https://graph.microsoft.com/v1.0"


def _app():
    cid = config.get("outlook_client_id").strip()
    if not cid:
        raise RuntimeError("Outlook Client ID not set. Add it in SETTINGS (see README, section Outlook).")
    cache = msal.SerializableTokenCache()
    if config.OUTLOOK_CACHE.exists():
        cache.deserialize(config.OUTLOOK_CACHE.read_text(encoding="utf-8"))
    app = msal.PublicClientApplication(cid, authority="https://login.microsoftonline.com/common", token_cache=cache)
    return app, cache


def _persist(cache):
    if cache.has_state_changed:
        config.OUTLOOK_CACHE.write_text(cache.serialize(), encoding="utf-8")


def sign_in() -> str:
    """BLOCKING interactive login. Run from a background thread."""
    app, cache = _app()
    res = app.acquire_token_interactive(SCOPES)
    _persist(cache)
    if "access_token" not in res:
        raise RuntimeError(res.get("error_description", "Outlook sign-in failed."))
    return res.get("id_token_claims", {}).get("preferred_username", "signed in")


def signed_in_user() -> str:
    try:
        app, _ = _app()
        a = app.get_accounts()
        return a[0]["username"] if a else ""
    except Exception:
        return ""


def _token() -> str:
    app, cache = _app()
    accts = app.get_accounts()
    if not accts:
        raise RuntimeError("Not signed in to Outlook. Use the ACCOUNTS tab -> Sign in to Outlook.")
    res = app.acquire_token_silent(SCOPES, account=accts[0])
    _persist(cache)
    if not res or "access_token" not in res:
        raise RuntimeError("Outlook session expired. Sign in again in the ACCOUNTS tab.")
    return res["access_token"]


def _h(extra=None):
    h = {"Authorization": f"Bearer {_token()}"}
    h.update(extra or {})
    return h


@safe
def outlook_list_emails(max_results: int = 5, unread_only: bool = False) -> str:
    """List recent emails from the Outlook inbox."""
    p = {"$top": max_results, "$select": "id,subject,from,receivedDateTime,bodyPreview,isRead",
         "$orderby": "receivedDateTime desc"}
    if unread_only:
        p["$filter"] = "isRead eq false"
    r = requests.get(f"{GRAPH}/me/mailFolders/inbox/messages", headers=_h(), params=p, timeout=30)
    r.raise_for_status()
    rows = [f"id={m['id']} | From: {m['from']['emailAddress']['address']} | {m['subject']} | "
            f"{m['receivedDateTime']} | {m['bodyPreview'][:150]}" for m in r.json().get("value", [])]
    return "\n".join(rows) or "No emails."


@safe
def outlook_read_email(message_id: str) -> str:
    """Read the full text of an Outlook email by id."""
    r = requests.get(f"{GRAPH}/me/messages/{message_id}", params={"$select": "subject,from,body,receivedDateTime"},
                     headers=_h({"Prefer": 'outlook.body-content-type="text"'}), timeout=30)
    r.raise_for_status()
    m = r.json()
    return f"From: {m['from']['emailAddress']['address']}\nSubject: {m['subject']}\n\n{m['body']['content'][:6000]}"


@safe
def outlook_send_email(to: str, subject: str, body: str) -> str:
    """Send an email through Outlook. The user must approve in a pop-up first."""
    r = request_approval("SEND EMAIL (Outlook)", {"To": to, "Subject": subject, "Body": body},
                         editable=["To", "Subject", "Body"])
    if r is None:
        return DENIED
    payload = {"message": {"subject": r["Subject"], "body": {"contentType": "Text", "content": r["Body"]},
                           "toRecipients": [{"emailAddress": {"address": a.strip()}} for a in r["To"].split(",") if a.strip()]}}
    resp = requests.post(f"{GRAPH}/me/sendMail", headers=_h(), json=payload, timeout=30)
    resp.raise_for_status()
    return f"Outlook email sent to {r['To']}."
