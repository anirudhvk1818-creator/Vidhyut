import io
import os
from pathlib import Path

from googleapiclient.http import MediaFileUpload, MediaIoBaseDownload

from core import config
from core.tooling import safe
from services import google_accounts as ga


def _esc(s: str) -> str:
    return s.replace("\\", "\\\\").replace("'", "\\'")


@safe
def drive_search(query: str = "", account: str = "", max_results: int = 10) -> str:
    """Search Google Drive by file name text. Returns id, name, type, link."""
    s, alias = ga.build("drive", "v3", account)
    q = "trashed=false" + (f" and name contains '{_esc(query)}'" if query else "")
    res = s.files().list(q=q, pageSize=max_results, fields="files(id,name,mimeType,webViewLink)").execute()
    rows = [f"id={f['id']} | {f['name']} | {f['mimeType']} | {f.get('webViewLink', '')}" for f in res.get("files", [])]
    return f"[{alias}]\n" + ("\n".join(rows) or "No files found.")


@safe
def drive_upload(file_path: str, account: str = "", folder_id: str = "") -> str:
    """Upload a local file from the PC to Google Drive (optionally into folder_id)."""
    if not os.path.isfile(file_path):
        return f"File not found: {file_path}"
    s, alias = ga.build("drive", "v3", account)
    meta = {"name": Path(file_path).name}
    if folder_id:
        meta["parents"] = [folder_id]
    f = s.files().create(body=meta, media_body=MediaFileUpload(file_path, resumable=True),
                         fields="id,webViewLink").execute()
    return f"Uploaded to Drive [{alias}]: {f.get('webViewLink')}"


@safe
def drive_download(file_id: str, account: str = "", save_dir: str = "") -> str:
    """Download a Drive file to the PC (default: Downloads folder). Google Docs/Sheets/Slides are exported as PDF."""
    s, alias = ga.build("drive", "v3", account)
    meta = s.files().get(fileId=file_id, fields="name,mimeType").execute()
    dest = Path(save_dir) if save_dir else config.DOWNLOADS_DIR
    dest.mkdir(parents=True, exist_ok=True)
    name = meta["name"]
    if meta["mimeType"].startswith("application/vnd.google-apps"):
        req = s.files().export_media(fileId=file_id, mimeType="application/pdf")
        name += ".pdf"
    else:
        req = s.files().get_media(fileId=file_id)
    path = dest / name
    with io.FileIO(path, "wb") as fh:
        dl = MediaIoBaseDownload(fh, req)
        done = False
        while not done:
            _, done = dl.next_chunk()
    return f"Downloaded to {path}"


@safe
def drive_create_folder(name: str, account: str = "", parent_id: str = "") -> str:
    """Create a folder in Google Drive."""
    s, alias = ga.build("drive", "v3", account)
    body = {"name": name, "mimeType": "application/vnd.google-apps.folder"}
    if parent_id:
        body["parents"] = [parent_id]
    f = s.files().create(body=body, fields="id").execute()
    return f"Folder '{name}' created, id={f['id']}"


@safe
def drive_move_file(file_id: str, new_folder_id: str, account: str = "") -> str:
    """Move a Drive file into another folder."""
    s, alias = ga.build("drive", "v3", account)
    cur = s.files().get(fileId=file_id, fields="parents").execute().get("parents", [])
    s.files().update(fileId=file_id, addParents=new_folder_id, removeParents=",".join(cur), fields="id").execute()
    return "File moved."
