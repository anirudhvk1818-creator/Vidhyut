"""Instagram Reels via the official Instagram Graph API (resumable local upload).
Needs: Instagram Business/Creator account linked to a Facebook Page, its IG user id, and a long-lived access token."""
import os
import time

import requests

from core import config
from core.approvals import DENIED, request_approval
from core.events import bus
from core.tooling import safe

G = "https://graph.facebook.com/v21.0"


def _check(r):
    try:
        j = r.json()
    except Exception:
        r.raise_for_status()
        return {}
    if r.status_code >= 400 or "error" in j:
        raise RuntimeError(j.get("error", {}).get("message", r.text)[:300])
    return j


@safe
def instagram_upload_reel(file_path: str, topic_hint: str = "") -> str:
    """Upload a video as an Instagram Reel with an AI-written caption and hashtags. User approval required."""
    from core.gemini_engine import engine
    uid, tok = config.get("ig_user_id"), config.get_secret("ig_access_token")
    if not uid or not tok:
        return "Instagram is not configured. Add the IG User ID and Access Token in SETTINGS."
    if not os.path.isfile(file_path):
        return f"Video file not found: {file_path}"
    hint = topic_hint or os.path.splitext(os.path.basename(file_path))[0]
    meta = engine.quick_json(f'Write an engaging Instagram Reel caption (max 2 short lines + a call to action) and '
                             f'10 relevant hashtags for a video about: {hint}. JSON keys: "caption", "hashtags" (array).')
    cap = meta.get("caption", hint) + "\n\n" + " ".join(meta.get("hashtags", []))
    r = request_approval("UPLOAD REEL TO INSTAGRAM", {"File": file_path, "Caption": cap}, editable=["Caption"])
    if r is None:
        return DENIED
    size = os.path.getsize(file_path)
    c = _check(requests.post(f"{G}/{uid}/media", data={
        "media_type": "REELS", "upload_type": "resumable", "caption": r["Caption"], "access_token": tok}, timeout=60))
    cid = c["id"]
    bus.status.emit("⬆ Instagram: uploading video …")
    with open(file_path, "rb") as f:
        up = requests.post(f"https://rupload.facebook.com/ig-api-upload/v21.0/{cid}",
                           headers={"Authorization": f"OAuth {tok}", "offset": "0", "file_size": str(size)},
                           data=f, timeout=1800)
    _check(up)
    for _ in range(60):  # up to ~5 min processing
        st = _check(requests.get(f"{G}/{cid}", params={"fields": "status_code", "access_token": tok}, timeout=30))
        code = st.get("status_code")
        bus.status.emit(f"Instagram processing: {code}")
        if code == "FINISHED":
            break
        if code in ("ERROR", "EXPIRED"):
            return f"Instagram rejected the video ({code})."
        time.sleep(5)
    pub = _check(requests.post(f"{G}/{uid}/media_publish", data={"creation_id": cid, "access_token": tok}, timeout=60))
    return f"Reel published on Instagram (media id {pub.get('id')})."
