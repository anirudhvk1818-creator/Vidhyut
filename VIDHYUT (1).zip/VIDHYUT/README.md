# VIDHYUT — Iron-Man-style AI Desktop Assistant (Windows)

## Folder structure
```
VIDHYUT/
├── main.py                  # entry point
├── requirements.txt
├── run_dev.bat              # install + run from source
├── build_exe.bat            # build dist\VIDHYUT.exe
├── core/
│   ├── config.py            # settings + secrets (API keys in Windows Credential Manager)
│   ├── events.py            # thread-safe GUI signal bus
│   ├── approvals.py         # Approve / Edit / Deny gate
│   ├── tooling.py           # error-safe tool wrapper
│   └── gemini_engine.py     # Gemini chat + function calling + Google Search grounding
├── services/
│   ├── google_accounts.py   # multi-account OAuth2 (one token file per account)
│   ├── gmail_service.py  drive_service.py  calendar_service.py  youtube_service.py
│   ├── instagram_service.py # Instagram Graph API Reels upload
│   ├── outlook_service.py   # Microsoft Graph mail
│   ├── browser_service.py   # Playwright persistent profile (uses Edge)
│   └── pc_service.py        # files, apps, downloads, installers, winget
├── tools/registry.py        # list of tools exposed to Gemini
└── ui/
    ├── theme.py  core_widget.py (animated reactor)  tts.py (edge-tts + mute)
    ├── approval_dialog.py  accounts_tab.py  settings_tab.py  main_window.py
```
Your data lives in `%APPDATA%\VIDHYUT` (tokens, settings, browser profile) — same for the script and the .exe.

## STEP 1 — Install Python
Download Python 3.11 or 3.12 from python.org. On the first installer screen **tick "Add python.exe to PATH"**.

## STEP 2 — Run it
Double-click `run_dev.bat` (first run installs everything). Or in a terminal: `pip install -r requirements.txt` then `python main.py`.

## STEP 3 — Gemini API key (free)
1. Go to https://aistudio.google.com/apikey → **Create API key**.
2. In VIDHYUT → **SETTINGS** → paste into *Gemini API key* → **Save**.
3. If you ever see "model not found", change *Gemini model* to a current model name from AI Studio.

## STEP 4 — Google `credentials.json` (Gmail, Drive, Calendar, YouTube)
1. Open https://console.cloud.google.com → create a **New Project** (name: VIDHYUT).
2. **APIs & Services → Library** → enable: *Gmail API*, *Google Drive API*, *Google Calendar API*, *YouTube Data API v3*.
3. **APIs & Services → OAuth consent screen** → User type **External** → fill app name + your email → Save.
4. On the same area, **Audience / Test users** → **Add users** → add every Gmail address you will connect.
5. (Recommended) Click **Publish app** (status "In production"). Without this, Google expires your logins every **7 days**. You'll see an "unverified app" warning when signing in — for your own use click *Advanced → Go to VIDHYUT*.
6. **Credentials → Create credentials → OAuth client ID** → Application type **Desktop app** → Create → **Download JSON**.
7. In VIDHYUT → SETTINGS → **IMPORT credentials.json** → pick that file.
8. **ACCOUNTS** tab → **＋ ADD GOOGLE ACCOUNT** → give it a name (e.g. `work-gmail`, `tech-youtube`) → sign in in the browser. Repeat for each account. For a YouTube brand channel, choose that channel when Google asks.

Then say things like: *"Check unread emails on work-gmail"*, *"Upload D:\videos\demo.mp4 to tech-youtube"*.

> **YouTube note:** videos uploaded through an API project that hasn't passed Google's audit are forced to **private**. Apply for the audit at the YouTube API Services "Audit and Quota Extension" form if you want public uploads. Default quota allows ~6 uploads/day.

## STEP 5 — Outlook (optional)
1. https://portal.azure.com → **App registrations → New registration**.
2. Supported account types: **Accounts in any organizational directory and personal Microsoft accounts**.
3. Redirect URI: platform **Mobile and desktop applications** → `http://localhost`.
4. After creating, copy **Application (client) ID** → VIDHYUT SETTINGS → *Outlook Client ID* → Save.
5. **API permissions → Add → Microsoft Graph → Delegated**: `Mail.ReadWrite`, `Mail.Send`, `User.Read`.
6. ACCOUNTS tab → **SIGN IN TO OUTLOOK**.

## STEP 6 — Instagram Reels (optional)
Requires an Instagram **Business or Creator** account linked to a Facebook Page, plus a Meta developer app with the `instagram_content_publish` permission. Get your **IG User ID** and a **long-lived access token** from the Graph API Explorer, paste both into SETTINGS. Reels are uploaded straight from your PC through Meta's official resumable upload.

## STEP 7 — Build the clickable .exe
Double-click **`build_exe.bat`**. After a few minutes you get `dist\VIDHYUT.exe` — copy it anywhere / pin it to your taskbar. (It's a single file, so it takes ~10 s to start. Windows Defender may warn on unsigned PyInstaller apps: *More info → Run anyway*.)

## Safety design
* Approve / Edit / Deny pop-up for: sending email (Gmail/Outlook), YouTube & Instagram uploads, deleting files, installing software, downloading program files, opening login/bank/payment sites.
* VIDHYUT never types passwords: use *"open the login page for X"*, sign in yourself once; the session is saved in VIDHYUT's private browser profile.
* API keys are stored in Windows Credential Manager, not in plain files.
