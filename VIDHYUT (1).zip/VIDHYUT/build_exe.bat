@echo off
REM Double-click this file to build VIDHYUT.exe  (result: dist\VIDHYUT.exe)
python -m venv venv
call venv\Scripts\activate
python -m pip install --upgrade pip
pip install -r requirements.txt
pyinstaller --noconfirm --clean --onefile --windowed --name VIDHYUT ^
  --collect-all playwright ^
  --collect-data googleapiclient ^
  --collect-submodules googleapiclient ^
  --collect-all google.genai ^
  --collect-all edge_tts ^
  --hidden-import keyring.backends.Windows ^
  main.py
echo.
echo Done! Your app is: %CD%\dist\VIDHYUT.exe
pause
