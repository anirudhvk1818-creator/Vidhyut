"""Every function in all_tools() is exposed to Gemini as a callable tool."""
import datetime

from core.tooling import safe


@safe
def web_search(query: str) -> str:
    """Search the live internet with Google Search grounding for current, real-time information."""
    from core.gemini_engine import engine
    return engine.grounded_search(query)


@safe
def get_current_datetime() -> str:
    """Current local date and time on the user's PC."""
    return datetime.datetime.now().strftime("%A, %d %B %Y, %H:%M")


@safe
def list_google_accounts() -> str:
    """List connected Google accounts (alias + email) and which is active."""
    from services import google_accounts as ga
    a, act = ga.list_accounts(), ga.active()
    return "\n".join(f"{k} <{v['email']}>{'  (ACTIVE)' if k == act else ''}" for k, v in a.items()) or "No accounts connected."


@safe
def set_active_google_account(alias: str) -> str:
    """Switch the default Google account used when no account is specified."""
    from services import google_accounts as ga
    a = ga.resolve(alias)
    ga.set_active(a)
    return f"Active account is now {a}."


def all_tools():
    from services import (browser_service as br, calendar_service as cal, drive_service as dr,
                          gmail_service as gm, instagram_service as ig, outlook_service as ol,
                          pc_service as pc, youtube_service as yt)
    return [
        web_search, get_current_datetime, list_google_accounts, set_active_google_account,
        gm.gmail_list_emails, gm.gmail_read_email, gm.gmail_send_email,
        ol.outlook_list_emails, ol.outlook_read_email, ol.outlook_send_email,
        dr.drive_search, dr.drive_upload, dr.drive_download, dr.drive_create_folder, dr.drive_move_file,
        cal.calendar_list_events, cal.calendar_create_event,
        yt.youtube_upload_video, ig.instagram_upload_reel,
        br.browser_open, br.browser_login_assist, br.browser_read_page, br.browser_click, br.browser_type,
        br.browser_download_by_click, br.browser_close,
        pc.search_files, pc.open_path, pc.launch_app, pc.delete_file, pc.move_file,
        pc.download_file, pc.run_installer, pc.winget_search, pc.winget_install,
    ]
