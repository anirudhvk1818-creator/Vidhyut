"""Animated 'arc reactor' AI core. States: idle / thinking / speaking."""
import math
import random

from PyQt6.QtCore import QPointF, QRectF, Qt, QTimer
from PyQt6.QtGui import QBrush, QColor, QFont, QPainter, QPen, QRadialGradient
from PyQt6.QtWidgets import QWidget

BLUE = QColor(0, 212, 255)
GOLD = QColor(255, 184, 0)

RINGS = [  # radius factor, colour, width, [(start, span)], rotation speed
    (0.95, BLUE, 2, [(0, 70), (120, 70), (240, 70)], 0.6),
    (0.82, GOLD, 3, [(30, 100), (200, 60)], -1.1),
    (0.68, BLUE, 2, [(0, 200)], 1.7),
    (0.55, GOLD, 2, [(60, 40), (180, 40), (300, 40)], -2.2),
]


class CoreWidget(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setMinimumSize(300, 300)
        self.state, self.t, self.level = "idle", 0.0, 0.1
        self.timer = QTimer(self)
        self.timer.timeout.connect(self._tick)
        self.timer.start(16)

    def set_state(self, s: str):
        self.state = s

    def _tick(self):
        speed = {"idle": 1.0, "thinking": 3.2, "speaking": 2.0}[self.state]
        self.t += 0.016 * speed
        if self.state == "speaking":
            target = 0.45 + 0.55 * abs(math.sin(self.t * 7) * math.sin(self.t * 2.3 + 1)) + random.uniform(-0.05, 0.05)
        elif self.state == "thinking":
            target = 0.35 + 0.15 * math.sin(self.t * 4)
        else:
            target = 0.12 + 0.06 * math.sin(self.t * 1.5)
        self.level += (max(0.0, min(1.0, target)) - self.level) * 0.25
        self.update()

    def paintEvent(self, _):
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        w, h = self.width(), self.height()
        c = QPointF(w / 2, h / 2)
        R = min(w, h) / 2 - 12
        L = self.level

        g = QRadialGradient(c, R * 1.05)
        g.setColorAt(0, QColor(0, 212, 255, int(50 + 120 * L)))
        g.setColorAt(0.55, QColor(0, 110, 190, int(15 + 45 * L)))
        g.setColorAt(1, QColor(0, 0, 0, 0))
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(QBrush(g))
        p.drawEllipse(c, R * 1.05, R * 1.05)

        # tick ring
        for i in range(72):
            a = math.radians(i * 5 + self.t * 12)
            r1 = R * 0.99
            r2 = r1 - (9 if i % 6 == 0 else 4)
            col = QColor(GOLD if i % 6 == 0 else BLUE)
            col.setAlpha(200 if i % 6 == 0 else 90)
            p.setPen(QPen(col, 1.4))
            p.drawLine(QPointF(c.x() + r1 * math.cos(a), c.y() + r1 * math.sin(a)),
                       QPointF(c.x() + r2 * math.cos(a), c.y() + r2 * math.sin(a)))

        # rotating arcs
        p.setBrush(Qt.BrushStyle.NoBrush)
        for rf, col, wd, arcs, sp in RINGS:
            r = R * rf * 0.93 * (1 + 0.02 * L * (1 if rf > 0.6 else -1))
            pen = QPen(col, wd)
            pen.setCapStyle(Qt.PenCapStyle.RoundCap)
            p.setPen(pen)
            rect = QRectF(c.x() - r, c.y() - r, 2 * r, 2 * r)
            for start, span in arcs:
                p.drawArc(rect, int((start + self.t * 40 * sp) * 16), int(span * 16))

        # reactor core
        cr = R * (0.24 + 0.08 * L)
        cg = QRadialGradient(c, cr * 1.6)
        cg.setColorAt(0, QColor(255, 255, 255, 255))
        cg.setColorAt(0.25, QColor(120, 235, 255, 240))
        cg.setColorAt(0.6, QColor(0, 160, 230, 150))
        cg.setColorAt(1, QColor(0, 0, 0, 0))
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(QBrush(cg))
        p.drawEllipse(c, cr * 1.6, cr * 1.6)
        p.setBrush(Qt.BrushStyle.NoBrush)
        p.setPen(QPen(GOLD, 2))
        p.drawEllipse(c, cr * 1.05, cr * 1.05)

        p.setPen(QPen(BLUE))
        f = QFont("Consolas", 9)
        f.setLetterSpacing(QFont.SpacingType.AbsoluteSpacing, 3)
        p.setFont(f)
        p.drawText(QRectF(0, h - 22, w, 20), Qt.AlignmentFlag.AlignCenter, self.state.upper())
