"""Voice output with edge-tts (free neural voices) + mute toggle."""
import asyncio
import re
import threading
import uuid

import edge_tts
from PyQt6.QtCore import QObject, QUrl, pyqtSignal
from PyQt6.QtMultimedia import QAudioOutput, QMediaPlayer

from core import config
from core.events import bus


def clean_for_speech(t: str) -> str:
    t = re.sub(r"```.*?```", " ", t, flags=re.S)
    t = re.sub(r"https?://\S+", "", t)
    t = re.sub(r"[*_#`>|]", " ", t)
    t = re.sub(r"\s+", " ", t).strip()
    if len(t) > 650:
        cut = t[:650]
        i = max(cut.rfind(". "), cut.rfind("? "), cut.rfind("! "))
        t = cut[: i + 1] if i > 200 else cut
    return t


class Speaker(QObject):
    speaking_changed = pyqtSignal(bool)
    _ready = pyqtSignal(str)

    def __init__(self):
        super().__init__()
        self.player = QMediaPlayer()
        self.audio = QAudioOutput()
        self.player.setAudioOutput(self.audio)
        self.player.playbackStateChanged.connect(
            lambda s: self.speaking_changed.emit(s == QMediaPlayer.PlaybackState.PlayingState))
        self._ready.connect(self._play)
        self.muted = bool(config.get("muted"))
        self._gen = 0
        for f in config.TEMP_DIR.glob("tts_*.mp3"):
            try:
                f.unlink()
            except Exception:
                pass

    def speak(self, text: str):
        text = clean_for_speech(text)
        if self.muted or not text:
            return
        self._gen += 1
        threading.Thread(target=self._synth, args=(text, self._gen), daemon=True).start()

    def _synth(self, text, gen):
        try:
            path = config.TEMP_DIR / f"tts_{uuid.uuid4().hex}.mp3"
            asyncio.run(edge_tts.Communicate(text, config.get("voice"), rate="+4%").save(str(path)))
            if gen == self._gen and not self.muted:
                self._ready.emit(str(path))
        except Exception as e:  # noqa
            bus.status.emit(f"Voice error (internet needed for TTS): {e}")

    def _play(self, path):
        self.player.setSource(QUrl.fromLocalFile(path))
        self.player.play()

    def set_muted(self, m: bool):
        self.muted = m
        config.set_many(muted=m)
        if m:
            self._gen += 1
            self.player.stop()
