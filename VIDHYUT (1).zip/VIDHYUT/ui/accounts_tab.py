import threading

from PyQt6.QtCore import pyqtSignal
from PyQt6.QtWidgets import (QAbstractItemView, QHBoxLayout, QHeaderView, QInputDialog, QLabel, QMessageBox,
                             QPushButton, QTableWidget, QTableWidgetItem, QVBoxLayout, QWidget)

from core.events import bus
from services import google_accounts as ga
from services import outlook_service as ol


class AccountsTab(QWidget):
    _done = pyqtSignal(bool, str)

    def __init__(self):
        super().__init__()
        self._done.connect(self._finished)
        lay = QVBoxLayout(self)
        h = QLabel("GOOGLE ACCOUNTS  (Gmail · Drive · Calendar · YouTube)")
        h.setStyleSheet("color:#ffb800;letter-spacing:2px;font-weight:600;")
        lay.addWidget(h)
        tip = QLabel("Name each account so you can say it in commands: e.g. personal-gmail, work-gmail, tech-youtube, second-channel. "
                     "For a YouTube channel, pick that channel/brand account on Google's consent screen.")
        tip.setWordWrap(True)
        tip.setStyleSheet("color:#7fa3b8;")
        lay.addWidget(tip)

        self.table = QTableWidget(0, 3)
        self.table.setHorizontalHeaderLabels(["ACTIVE", "ALIAS", "EMAIL"])
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        self.table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        lay.addWidget(self.table)

        row = QHBoxLayout()
        for text, fn, name in [("＋ ADD GOOGLE ACCOUNT", self.add, "gold"), ("RE-AUTHENTICATE", self.reauth, ""),
                               ("SET ACTIVE", self.set_active, ""), ("REMOVE", self.remove, "deny")]:
            b = QPushButton(text)
            if name:
                b.setObjectName(name)
            b.clicked.connect(fn)
            row.addWidget(b)
        lay.addLayout(row)

        o = QLabel("MICROSOFT OUTLOOK")
        o.setStyleSheet("color:#ffb800;letter-spacing:2px;font-weight:600;margin-top:14px;")
        lay.addWidget(o)
        orow = QHBoxLayout()
        self.ol_lbl = QLabel("")
        b = QPushButton("SIGN IN TO OUTLOOK")
        b.clicked.connect(self.outlook_sign_in)
        orow.addWidget(self.ol_lbl, 1)
        orow.addWidget(b)
        lay.addLayout(orow)
        lay.addStretch()

        bus.accounts_changed.connect(self.refresh)
        self.refresh()

    def refresh(self):
        accts, act = ga.list_accounts(), ga.active()
        self.table.setRowCount(len(accts))
        for i, (alias, m) in enumerate(accts.items()):
            for j, v in enumerate(["● ACTIVE" if alias == act else "", alias, m.get("email", "")]):
                self.table.setItem(i, j, QTableWidgetItem(v))
        u = ol.signed_in_user()
        self.ol_lbl.setText(f"Signed in as {u}" if u else "Not signed in")

    def _selected(self):
        r = self.table.currentRow()
        return self.table.item(r, 1).text() if r >= 0 else None

    def _run(self, fn):
        def work():
            try:
                self._done.emit(True, str(fn()))
            except Exception as e:  # noqa
                self._done.emit(False, str(e))
        threading.Thread(target=work, daemon=True).start()
        bus.status.emit("Waiting for sign-in in your browser …")

    def add(self):
        alias, ok = QInputDialog.getText(self, "Add account", "Name for this account (e.g. work-gmail, tech-youtube):")
        if ok and alias.strip():
            self._run(lambda: "Connected: " + ga.add_account(alias))

    def reauth(self):
        a = self._selected()
        if a:
            self._run(lambda: "Re-authenticated: " + ga.add_account(a))

    def set_active(self):
        a = self._selected()
        if a:
            ga.set_active(a)

    def remove(self):
        a = self._selected()
        if a and QMessageBox.question(self, "Remove", f"Remove '{a}'?") == QMessageBox.StandardButton.Yes:
            ga.remove(a)

    def outlook_sign_in(self):
        self._run(lambda: "Outlook: " + ol.sign_in())

    def _finished(self, ok, msg):
        bus.status.emit(msg)
        if not ok:
            QMessageBox.warning(self, "VIDHYUT", msg)
        self.refresh()
