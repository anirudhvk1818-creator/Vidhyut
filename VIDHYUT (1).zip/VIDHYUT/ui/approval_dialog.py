from PyQt6.QtCore import Qt
from PyQt6.QtWidgets import (QDialog, QFormLayout, QHBoxLayout, QLabel, QLineEdit, QPlainTextEdit,
                             QPushButton, QVBoxLayout)


class ApprovalDialog(QDialog):
    """Approve / Edit / Deny pop-up. Fields are read-only until the user presses Edit."""

    def __init__(self, req, parent=None):
        super().__init__(parent)
        self.req = req
        self.setWindowTitle("VIDHYUT — Approval Required")
        self.setModal(True)
        self.setMinimumWidth(640)
        lay = QVBoxLayout(self)
        t = QLabel("⚠  APPROVAL REQUIRED")
        t.setObjectName("approvalTitle")
        lay.addWidget(t)
        act = QLabel(req.action)
        act.setStyleSheet("color:#00d4ff;font-size:15px;font-weight:600;")
        lay.addWidget(act)
        if req.note:
            n = QLabel(req.note)
            n.setWordWrap(True)
            n.setStyleSheet("color:#9fb8c8;")
            lay.addWidget(n)

        form = QFormLayout()
        self.widgets = {}
        for k, v in req.fields.items():
            big = "\n" in v or len(v) > 90 or k.lower() in ("body", "description", "caption")
            w = QPlainTextEdit(v) if big else QLineEdit(v)
            if big:
                w.setMinimumHeight(150 if k.lower() == "body" else 100)
            w.setReadOnly(True)
            self.widgets[k] = w
            form.addRow(QLabel(k + ":"), w)
        lay.addLayout(form)

        self.hint = QLabel("")
        self.hint.setStyleSheet("color:#ffb800;")
        lay.addWidget(self.hint)

        row = QHBoxLayout()
        row.addStretch()
        self.btn_deny = QPushButton("DENY")
        self.btn_deny.setObjectName("deny")
        self.btn_edit = QPushButton("EDIT")
        self.btn_edit.setObjectName("gold")
        self.btn_ok = QPushButton("APPROVE")
        self.btn_ok.setObjectName("approve")
        self.btn_deny.clicked.connect(self.reject)
        self.btn_edit.clicked.connect(self._edit)
        self.btn_ok.clicked.connect(self.accept)
        row.addWidget(self.btn_deny)
        if req.editable:
            row.addWidget(self.btn_edit)
        row.addWidget(self.btn_ok)
        lay.addLayout(row)

    def _edit(self):
        for k in self.req.editable:
            w = self.widgets[k]
            w.setReadOnly(False)
            w.setStyleSheet("border:1px solid #ffb800;")
        self.btn_edit.setEnabled(False)
        self.hint.setText("Editing enabled (gold fields). Click APPROVE when ready.")

    def values(self):
        return {k: (w.toPlainText() if isinstance(w, QPlainTextEdit) else w.text()) for k, w in self.widgets.items()}
