import html
import re
from concurrent.futures import ThreadPoolExecutor

from PyQt6.QtCore import Qt
from PyQt6.QtWidgets import (QFrame, QHBoxLayout, QLabel, QLineEdit, QMainWindow, QPushButton, QTabWidget,
                             QTextBrowser, QVBoxLayout, QWidget)

from core import config
from core.events import bus
from core.gemini_engine import engine
from ui.accounts_tab import AccountsTab
from ui.approval_dialog import ApprovalDialog
from ui.core_widget import CoreWidget
from ui.settings_tab import SettingsTab
from ui.tts import Speaker


def to_html(text: str) -> str:
    t = html.escape(text)
    t = re.sub(r"\*\*(.+?)\*\*", r"<b>\1</b>", t)
    t = re.sub(r"(https?://[^\s<]+)", r'<a style="color:#00d4ff" href="\1">\1</a>', t)
    return t.replace("\n", "<br>")


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("VIDHYUT")
        self.resize(1220, 780)
        # ONE worker thread: Playwright & Gemini tool calls always run on the same thread.
        self.executor = ThreadPoolExecutor(max_workers=1)
        self.speaker = Speaker()

        root = QWidget()
        root.setObjectName("root")
        self.setCentralWidget(root)
        outer = QHBoxLayout(root)

        # ---- left: core ----
        left = QFrame()
        left.setObjectName("panel")
        left.setFixedWidth(380)
        ll = QVBoxLayout(left)
        title = QLabel("VIDHYUT")
        title.setObjectName("title")
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        sub = QLabel("PERSONAL AI SYSTEM · ONLINE")
        sub.setObjectName("sub")
        sub.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.core = CoreWidget()
        self.status = QLabel("Ready")
        self.status.setObjectName("status")
        self.status.setWordWrap(True)
        self.status.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.mute_btn = QPushButton()
        self.mute_btn.clicked.connect(self.toggle_mute)
        ll.addWidget(title)
        ll.addWidget(sub)
        ll.addWidget(self.core, 1)
        ll.addWidget(self.status)
        ll.addWidget(self.mute_btn)
        self._mute_label()

        # ---- right: tabs ----
        tabs = QTabWidget()
        console = QWidget()
        cl = QVBoxLayout(console)
        self.chat = QTextBrowser()
        self.chat.setOpenExternalLinks(True)
        row = QHBoxLayout()
        self.input = QLineEdit()
        self.input.setPlaceholderText("Type a command…  e.g. “Check unread mail on my work Gmail”")
        self.input.returnPressed.connect(self.send)
        self.send_btn = QPushButton("SEND ▶")
        self.send_btn.setObjectName("gold")
        self.send_btn.clicked.connect(self.send)
        row.addWidget(self.input, 1)
        row.addWidget(self.send_btn)
        cl.addWidget(self.chat, 1)
        cl.addLayout(row)
        tabs.addTab(console, "CONSOLE")
        tabs.addTab(AccountsTab(), "ACCOUNTS")
        tabs.addTab(SettingsTab(self._settings_saved), "SETTINGS")
        self.tabs = tabs
        outer.addWidget(left)
        outer.addWidget(tabs, 1)

        bus.status.connect(self.status.setText)
        bus.reply_ready.connect(self.on_reply)
        bus.approval_requested.connect(self.on_approval)
        self.speaker.speaking_changed.connect(lambda s: self.core.set_state("speaking" if s else "idle"))

        if config.get_secret("gemini_api_key"):
            self.say("VIDHYUT online. All systems nominal. How may I assist?")
            self.speaker.speak("VIDHYUT online. How may I assist?")
        else:
            self.say("Welcome. Open the SETTINGS tab, paste your Google AI Studio API key and press Save.")
            tabs.setCurrentIndex(2)

    # ---- chat ----
    def say(self, text, who="VIDHYUT", color="#00d4ff"):
        self.chat.append(f'<p><span style="color:{color};font-weight:700;letter-spacing:2px">{who} ›</span> '
                         f'{to_html(text)}</p>')
        self.chat.verticalScrollBar().setValue(self.chat.verticalScrollBar().maximum())

    def send(self):
        text = self.input.text().strip()
        if not text:
            return
        self.input.clear()
        self.say(text, "YOU", "#ffb800")
        self.send_btn.setEnabled(False)
        self.core.set_state("thinking")
        self.executor.submit(self._work, text)

    @staticmethod
    def _work(text):
        try:
            bus.reply_ready.emit(engine.ask(text), False)
        except Exception as e:  # noqa
            bus.reply_ready.emit(f"⚠ {e}", True)

    def on_reply(self, text, is_err):
        self.send_btn.setEnabled(True)
        self.core.set_state("idle")
        self.status.setText("Ready")
        self.say(text)
        if not is_err:
            self.speaker.speak(text)

    # ---- approvals ----
    def on_approval(self, req):
        self.raise_()
        self.activateWindow()
        dlg = ApprovalDialog(req, self)
        ok = dlg.exec() == dlg.DialogCode.Accepted
        req.result = dlg.values() if ok else None
        req.event.set()
        self.say(("✔ Approved: " if ok else "✖ Denied: ") + req.action, "SECURITY", "#19e68c" if ok else "#ff4d5e")

    # ---- misc ----
    def toggle_mute(self):
        self.speaker.set_muted(not self.speaker.muted)
        self._mute_label()

    def _mute_label(self):
        self.mute_btn.setText("🔇 VOICE: MUTED" if self.speaker.muted else "🔊 VOICE: ON")

    def _settings_saved(self):
        self.say("Settings updated.")

    def closeEvent(self, e):
        try:
            from services import browser_service
            self.executor.submit(browser_service.shutdown).result(timeout=8)
        except Exception:
            pass
        self.executor.shutdown(wait=False, cancel_futures=True)
        e.accept()
