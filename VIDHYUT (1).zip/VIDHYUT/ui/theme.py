BG = "#04070d"
PANEL = "#08111f"
BLUE = "#00d4ff"
GOLD = "#ffb800"
TEXT = "#cfeaff"

QSS = f"""
* {{ font-family: 'Segoe UI', 'Consolas'; color: {TEXT}; font-size: 13px; }}
QMainWindow, QDialog, QWidget#root {{ background: {BG}; }}
QFrame#panel {{ background: {PANEL}; border: 1px solid #0b3a52; border-radius: 12px; }}
QLabel#title {{ color: {GOLD}; font-size: 26px; font-weight: 700; letter-spacing: 8px; }}
QLabel#sub {{ color: {BLUE}; font-size: 11px; letter-spacing: 3px; }}
QLabel#status {{ color: #6fa8c4; font-size: 11px; }}
QLabel#approvalTitle {{ color: {GOLD}; font-size: 18px; font-weight: 700; letter-spacing: 3px; }}
QTabWidget::pane {{ border: 1px solid #0b3a52; border-radius: 10px; background: {PANEL}; }}
QTabBar::tab {{ background: #06101c; padding: 9px 22px; border: 1px solid #0b3a52; border-bottom: none;
               border-top-left-radius: 8px; border-top-right-radius: 8px; color: #6fa8c4; letter-spacing: 2px; }}
QTabBar::tab:selected {{ background: {PANEL}; color: {BLUE}; border-color: {BLUE}; }}
QTextBrowser, QPlainTextEdit, QLineEdit, QComboBox, QTableWidget {{
    background: #050c16; border: 1px solid #0b3a52; border-radius: 8px; padding: 6px;
    selection-background-color: {BLUE}; selection-color: black; }}
QLineEdit:focus, QPlainTextEdit:focus, QComboBox:focus {{ border: 1px solid {BLUE}; }}
QHeaderView::section {{ background: #06101c; color: {GOLD}; border: none; padding: 6px; }}
QPushButton {{ background: #07202f; border: 1px solid {BLUE}; border-radius: 8px; padding: 8px 16px; color: {BLUE};
              letter-spacing: 1px; }}
QPushButton:hover {{ background: {BLUE}; color: black; }}
QPushButton:disabled {{ border-color: #234; color: #345; }}
QPushButton#approve {{ border-color: #19e68c; color: #19e68c; }}
QPushButton#approve:hover {{ background: #19e68c; color: black; }}
QPushButton#deny {{ border-color: #ff4d5e; color: #ff4d5e; }}
QPushButton#deny:hover {{ background: #ff4d5e; color: black; }}
QPushButton#gold {{ border-color: {GOLD}; color: {GOLD}; }}
QPushButton#gold:hover {{ background: {GOLD}; color: black; }}
QScrollBar:vertical {{ background: {BG}; width: 10px; }}
QScrollBar::handle:vertical {{ background: #0b3a52; border-radius: 5px; }}
QScrollBar::add-line, QScrollBar::sub-line {{ height: 0; }}
"""
