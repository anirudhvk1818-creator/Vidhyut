import shutil

from PyQt6.QtWidgets import (QComboBox, QFileDialog, QFormLayout, QLabel, QLineEdit, QMessageBox, QPushButton,
                             QVBoxLayout, QWidget)

from core import config
from core.gemini_engine import engine


class SettingsTab(QWidget):
    def __init__(self, on_saved):
        super().__init__()
        self.on_saved = on_saved
        lay = QVBoxLayout(self)
        form = QFormLayout()

        self.key = QLineEdit(config.get_secret("gemini_api_key"))
        self.key.setEchoMode(QLineEdit.EchoMode.Password)
        self.key.setPlaceholderText("Paste Google AI Studio API key (aistudio.google.com/apikey)")
        self.model = QComboBox()
        self.model.setEditable(True)
        self.model.addItems(["gemini-flash-latest", "gemini-2.5-flash", "gemini-2.5-pro", "gemini-pro-latest"])
        self.model.setCurrentText(config.get("model"))
        self.voice = QComboBox()
        self.voice.setEditable(True)
        self.voice.addItems(["en-GB-RyanNeural", "en-US-GuyNeural", "en-US-AriaNeural", "en-IN-PrabhatNeural",
                             "en-IN-NeerjaNeural", "hi-IN-MadhurNeural", "hi-IN-SwaraNeural"])
        self.voice.setCurrentText(config.get("voice"))
        self.name = QLineEdit(config.get("user_name"))
        self.tz = QLineEdit(config.get("timezone"))
        self.ol_id = QLineEdit(config.get("outlook_client_id"))
        self.ol_id.setPlaceholderText("Azure app (client) ID")
        self.ig_id = QLineEdit(config.get("ig_user_id"))
        self.ig_tok = QLineEdit(config.get_secret("ig_access_token"))
        self.ig_tok.setEchoMode(QLineEdit.EchoMode.Password)

        form.addRow("Gemini API key", self.key)
        form.addRow("Gemini model", self.model)
        form.addRow("Voice (edge-tts)", self.voice)
        form.addRow("Your name", self.name)
        form.addRow("Timezone (calendar)", self.tz)
        form.addRow("Outlook Client ID", self.ol_id)
        form.addRow("Instagram User ID", self.ig_id)
        form.addRow("Instagram Access Token", self.ig_tok)
        lay.addLayout(form)

        self.cred_lbl = QLabel()
        b_cred = QPushButton("IMPORT credentials.json (Google OAuth)")
        b_cred.setObjectName("gold")
        b_cred.clicked.connect(self.import_creds)
        lay.addWidget(b_cred)
        lay.addWidget(self.cred_lbl)
        b = QPushButton("SAVE SETTINGS")
        b.setObjectName("approve")
        b.clicked.connect(self.save)
        lay.addWidget(b)
        lay.addStretch()
        self._cred_status()

    def _cred_status(self):
        ok = config.CREDENTIALS_FILE.exists()
        self.cred_lbl.setText("✔ credentials.json imported" if ok else "✖ credentials.json not imported yet")
        self.cred_lbl.setStyleSheet("color:#19e68c;" if ok else "color:#ff4d5e;")

    def import_creds(self):
        f, _ = QFileDialog.getOpenFileName(self, "Select credentials.json", "", "JSON (*.json)")
        if f:
            shutil.copy(f, config.CREDENTIALS_FILE)
            self._cred_status()

    def save(self):
        config.set_secret("gemini_api_key", self.key.text().strip())
        config.set_secret("ig_access_token", self.ig_tok.text().strip())
        config.set_many(model=self.model.currentText().strip(), voice=self.voice.currentText().strip(),
                        user_name=self.name.text().strip() or "Boss", timezone=self.tz.text().strip(),
                        outlook_client_id=self.ol_id.text().strip(), ig_user_id=self.ig_id.text().strip())
        engine.reset()
        self.on_saved()
        QMessageBox.information(self, "VIDHYUT", "Settings saved.")
