"""Gemini brain: chat + function calling + (via a tool) Google Search grounding.

Why grounding is a separate call: not every Gemini model allows built-in Google Search and
custom function calling in the SAME request, so `web_search` is a tool that makes its own
grounded request. This works on every model.
"""
import datetime
import json
import re

from google import genai
from google.genai import types

from core import config


class Engine:
    def __init__(self):
        self._client = None
        self._client_key = None
        self.chat = None
        self._sig = None

    # ---------- client ----------
    def client(self):
        key = config.get_secret("gemini_api_key").strip()
        if not key:
            raise RuntimeError("No Gemini API key yet. Open the SETTINGS tab and paste your Google AI Studio key.")
        if key != self._client_key:
            self._client = genai.Client(api_key=key)
            self._client_key = key
        return self._client

    def reset(self):
        self.chat = None
        self._sig = None

    def _system(self):
        name = config.get("user_name") or "Boss"
        now = datetime.datetime.now().strftime("%A, %d %B %Y, %H:%M")
        return (
            f"You are VIDHYUT, a personal AI assistant living on {name}'s Windows PC. "
            f"Tone: calm, sharp, slightly witty, loyal. Address the user as {name}. Now: {now}.\n"
            "RULES:\n"
            "- Replies are spoken aloud: keep them short (1-4 sentences) unless detail is requested. No tables.\n"
            "- For anything current/real-time (news, prices, scores, facts that change) call web_search.\n"
            "- The user has several Google accounts. If they name one ('second Gmail', 'tech channel'), call "
            "list_google_accounts first and pass the EXACT alias in the `account` argument. If none named, leave it empty.\n"
            "- Sending emails, uploading videos, installing software, deleting files, and sensitive logins trigger an "
            "Approve/Edit/Deny pop-up handled by the app. Just call the tool; do not ask for confirmation in chat.\n"
            "- If a tool returns 'USER DENIED', acknowledge briefly and stop. Never claim success unless a tool says so.\n"
            "- For rough email drafts, rewrite them professionally yourself, then call the send tool with the polished text.\n"
            "- Never ask for, type, or store passwords. For logins use browser_login_assist so the user logs in manually.\n"
            "- If a tool errors, explain simply what the user should fix."
        )

    def _ensure_chat(self):
        client = self.client()
        model = config.get("model")
        sig = (self._client_key, model, config.get("user_name"))
        if self.chat is None or sig != self._sig:
            from tools.registry import all_tools
            self.chat = client.chats.create(
                model=model,
                config=types.GenerateContentConfig(
                    system_instruction=self._system(),
                    tools=all_tools(),
                    automatic_function_calling=types.AutomaticFunctionCallingConfig(maximum_remote_calls=15),
                    temperature=0.6,
                ),
            )
            self._sig = sig

    # ---------- public ----------
    def ask(self, text: str) -> str:
        self._ensure_chat()
        resp = self.chat.send_message(text)
        return (resp.text or "").strip() or "Done."

    def grounded_search(self, query: str) -> str:
        r = self.client().models.generate_content(
            model=config.get("model"),
            contents=query,
            config=types.GenerateContentConfig(tools=[types.Tool(google_search=types.GoogleSearch())]),
        )
        out = r.text or "No answer."
        try:
            chunks = r.candidates[0].grounding_metadata.grounding_chunks or []
            srcs = [f"- {c.web.title}: {c.web.uri}" for c in chunks[:5] if getattr(c, "web", None)]
            if srcs:
                out += "\n\nSources:\n" + "\n".join(srcs)
        except Exception:
            pass
        return out

    def quick_text(self, prompt: str, json_mode: bool = False) -> str:
        cfg = types.GenerateContentConfig(response_mime_type="application/json") if json_mode else None
        r = self.client().models.generate_content(model=config.get("model"), contents=prompt, config=cfg)
        return r.text or ""

    def quick_json(self, prompt: str) -> dict:
        text = self.quick_text(prompt + "\nReturn ONLY valid JSON, no markdown.", json_mode=True)
        try:
            return json.loads(text)
        except Exception:
            m = re.search(r"\{.*\}", text, re.S)
            return json.loads(m.group(0)) if m else {}


engine = Engine()
