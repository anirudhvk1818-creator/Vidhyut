"""Approve / Edit / Deny gate. Worker thread blocks until the GUI answers."""
import threading
from core.events import bus


class ApprovalRequest:
    def __init__(self, action, fields, editable, note):
        self.action = action
        self.fields = {k: str(v) for k, v in fields.items()}
        self.editable = list(editable)
        self.note = note
        self.event = threading.Event()
        self.result = None   # dict of (possibly edited) values, or None = denied


def request_approval(action: str, fields: dict, editable=(), note: str = ""):
    """Returns dict of final field values, or None if the user denied."""
    req = ApprovalRequest(action, fields, editable, note)
    bus.approval_requested.emit(req)
    req.event.wait()
    return req.result


DENIED = "USER DENIED this action. Do not retry unless the user asks again."
