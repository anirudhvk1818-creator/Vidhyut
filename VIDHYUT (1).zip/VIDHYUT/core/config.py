"""Settings + secrets. Everything lives in %APPDATA%\\VIDHYUT (same for .py and .exe)."""
import json
import os
from pathlib import Path

APP_NAME = "VIDHYUT"


def _data_dir() -> Path:
    if os.name == "nt":
        base = Path(os.environ.get("APPDATA", str(Path.home()))) / APP_NAME
    else:
        base = Path.home() / ".vidhyut"
    base.mkdir(parents=True, exist_ok=True)
    return base


DATA_DIR = _data_dir()
TOKENS_DIR = DATA_DIR / "tokens"
TEMP_DIR = DATA_DIR / "temp"
PROFILE_DIR = DATA_DIR / "browser_profile"
for _d in (TOKENS_DIR, TEMP_DIR, PROFILE_DIR):
    _d.mkdir(parents=True, exist_ok=True)

CREDENTIALS_FILE = DATA_DIR / "credentials.json"   # Google OAuth client file
ACCOUNTS_FILE = DATA_DIR / "accounts.json"
SETTINGS_FILE = DATA_DIR / "settings.json"
SECRETS_FALLBACK = DATA_DIR / "secrets.json"       # only used if Windows keyring fails
OUTLOOK_CACHE = DATA_DIR / "outlook_cache.bin"
DOWNLOADS_DIR = Path.home() / "Downloads"

DEFAULTS = {
    "model": "gemini-flash-latest",
    "voice": "en-GB-RyanNeural",
    "muted": False,
    "user_name": "Boss",
    "timezone": "Asia/Kolkata",
    "outlook_client_id": "",
    "ig_user_id": "",
}

_cache = None


def _load():
    global _cache
    if _cache is None:
        _cache = dict(DEFAULTS)
        try:
            _cache.update(json.loads(SETTINGS_FILE.read_text(encoding="utf-8")))
        except Exception:
            pass
    return _cache


def get(key):
    return _load().get(key, DEFAULTS.get(key))


def set_many(**kw):
    _load().update(kw)
    SETTINGS_FILE.write_text(json.dumps(_load(), indent=2), encoding="utf-8")


# ---- secrets (API key, Instagram token) ----
def get_secret(name: str) -> str:
    try:
        import keyring
        v = keyring.get_password(APP_NAME, name)
        if v:
            return v
    except Exception:
        pass
    try:
        return json.loads(SECRETS_FALLBACK.read_text(encoding="utf-8")).get(name, "")
    except Exception:
        return ""


def set_secret(name: str, value: str):
    try:
        import keyring
        keyring.set_password(APP_NAME, name, value)
        return
    except Exception:
        pass
    data = {}
    try:
        data = json.loads(SECRETS_FALLBACK.read_text(encoding="utf-8"))
    except Exception:
        pass
    data[name] = value
    SECRETS_FALLBACK.write_text(json.dumps(data), encoding="utf-8")
