"""Thread-safe signal bus between worker thread and the GUI."""
from PyQt6.QtCore import QObject, pyqtSignal


class Bus(QObject):
    status = pyqtSignal(str)               # small status line text
    approval_requested = pyqtSignal(object)  # ApprovalRequest
    reply_ready = pyqtSignal(str, bool)    # text, is_error
    accounts_changed = pyqtSignal()


bus = Bus()
