import functools
from core.events import bus


def safe(fn):
    """Wrap a tool so errors go back to Gemini as text instead of crashing the chat."""
    @functools.wraps(fn)
    def wrapper(*a, **k):
        bus.status.emit(f"⚙ running {fn.__name__} …")
        try:
            return fn(*a, **k)
        except Exception as e:  # noqa
            return f"ERROR in {fn.__name__}: {e}"
    return wrapper
