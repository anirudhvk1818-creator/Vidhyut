"""VIDHYUT - futuristic AI desktop assistant. Run: python main.py"""
import sys
from PyQt6.QtWidgets import QApplication
from ui.theme import QSS
from ui.main_window import MainWindow


def main():
    app = QApplication(sys.argv)
    app.setApplicationName("VIDHYUT")
    app.setStyleSheet(QSS)
    win = MainWindow()
    win.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
